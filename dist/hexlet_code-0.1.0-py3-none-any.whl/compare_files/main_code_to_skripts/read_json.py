import json

def read_json():
    with open('file1.json', 'r') as file1, open('file2.json', 'r') as file2:
        info_from_file1 = file1.read()
        info_from_file2 = file2.read()

    return json.loads(info_from_file1), json.loads(info_from_file2)