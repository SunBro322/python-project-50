#!/usr/bin/env python3
from compare_files.main_code_to_skripts import main_code

def main():
    main_code.generate_diff()



if __name__ == '__main__':
    main()