import json


def create_json(d_list):
    return json.dumps(d_list, indent=4)